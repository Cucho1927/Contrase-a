import java.util.Scanner;

class InvalidPasswordException extends Exception {
    public InvalidPasswordException(String message) {
        super(message);
    }
}

class PasswordMismatchException extends Exception {
    public PasswordMismatchException(String message) {
        super(message);
    }
}

public class PasswordValidator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("Ingrese su contraseña:");
            String password1 = scanner.nextLine();

            System.out.println("Confirme su contraseña:");
            String password2 = scanner.nextLine();

            validatePasswords(password1, password2);

            System.out.println("Contraseña válida y confirmada con éxito.");
        } catch (InvalidPasswordException | PasswordMismatchException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static void validatePasswords(String password1, String password2)
            throws InvalidPasswordException, PasswordMismatchException {
        if (!password1.equals(password2)) {
            throw new PasswordMismatchException("Las contraseñas no coinciden.");
        }

        if (password1.length() < 8) {
            throw new InvalidPasswordException("La contraseña debe tener al menos 8 caracteres.");
        }

        if (password1.contains(" ")) {
            throw new InvalidPasswordException("La contraseña no puede contener espacios en blanco.");
        }

        boolean hasCharacter = false;
        boolean hasUpperCase = false;
        boolean hasNumber = false;
        boolean hasSpecialCharacter = false;

        for (char c : password1.toCharArray()) {
            if (Character.isLetter(c)) {
                hasCharacter = true;
                if (Character.isUpperCase(c)) {
                    hasUpperCase = true;
                }
            } else if (Character.isDigit(c)) {
                hasNumber = true;
            } else {
                hasSpecialCharacter = true;
            }
        }

        if (!hasCharacter || !hasUpperCase || !hasNumber || !hasSpecialCharacter) {
            throw new InvalidPasswordException("La contraseña debe contener al menos un carácter, una mayúscula, un número y un carácter especial.");
        }
    }
}
